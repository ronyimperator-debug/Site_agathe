Recréation structurée du site pour déploiement sur Netlify.
Remplace les images dans assets/images par les originaux, modifie textes et liens.
Pour déployer : zip le dossier et glisse-dépose sur Netlify, ou push sur GitHub et connecte le repo.
